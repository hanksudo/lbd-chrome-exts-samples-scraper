# Document Scanning API Sample

This demo interfaces with the Chrome document scanning API to acquire scanned
images.

## APIs

* [Document scanning API](https://developer.chrome.com/apps/document_scan)
* [Runtime](https://developer.chrome.com/apps/runtime)
* [Window](https://developer.chrome.com/apps/app_window)
